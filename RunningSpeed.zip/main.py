# Enter your code here

miles = int(input("How many miles did you run? "))

mins = int(input("How many minutes did it take you? "))

convert = mins/60

mph = miles/convert

print("speed in mph: " + str(mph))